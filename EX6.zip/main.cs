using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Quantos números deseja verificar?");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Digite o número {i + 1}: ");
            int numero = int.Parse(Console.ReadLine());

            bool positivo = VerificarPositivo(numero);
            if (positivo)
            {
                Console.WriteLine("O número é positivo.");
            }
            else
            {
                Console.WriteLine("O número é negativo.");
            }
        }
    }

    static bool VerificarPositivo(int numero)
    {
        // Retorna verdadeiro se o número é positivo, caso contrário, retorna falso
        return numero >= 0;
    }
}
