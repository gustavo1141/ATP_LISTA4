using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Quantos conjuntos de 3 valores deseja ordenar?");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nConjunto {i + 1}:");
            Console.Write("Digite o primeiro valor: ");
            int valor1 = int.Parse(Console.ReadLine());

            Console.Write("Digite o segundo valor: ");
            int valor2 = int.Parse(Console.ReadLine());

            Console.Write("Digite o terceiro valor: ");
            int valor3 = int.Parse(Console.ReadLine());

            OrdenarExibirValores(valor1, valor2, valor3);
        }
    }

    static void OrdenarExibirValores(int a, int b, int c)
    {
        // Ordena os valores
        int temp;
        if (a > b)
        {
            temp = a;
            a = b;
            b = temp;
        }
        if (a > c)
        {
            temp = a;
            a = c;
            c = temp;
        }
        if (b > c)
        {
            temp = b;
            b = c;
            c = temp;
        }

        // Exibe os valores ordenados
        Console.WriteLine($"Valores em ordem crescente: {a}, {b}, {c}");
    }
}
