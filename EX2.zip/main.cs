using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite os dados dos habitantes. Digite 0 para o salário para encerrar.");

        // Variáveis para cálculo da média
        int totalPessoas = 0;
        double somaSalarios = 0;

        // Loop para coletar os dados dos habitantes
        while (true)
        {
            Console.Write("Salário: ");
            double salario = double.Parse(Console.ReadLine());

            // Verifica se o salário é 0 para encerrar a entrada de dados
            if (salario == 0)
                break;

            Console.Write("Número de filhos: ");
            int numFilhos = int.Parse(Console.ReadLine());

            // Adiciona os dados para cálculo da média
            somaSalarios += salario;
            totalPessoas++;
        }

        // Verifica se pelo menos uma pessoa foi inserida
        if (totalPessoas > 0)
        {
            double mediaSalarios = somaSalarios / totalPessoas;
            Console.WriteLine($"A média de salário da população é: {mediaSalarios:C}");
        }
        else
        {
            Console.WriteLine("Nenhum dado foi inserido.");
        }
    }
}
