using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Quantos alunos deseja verificar?");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Digite a média do aluno {i + 1}: ");
            double media = double.Parse(Console.ReadLine());

            ExibirConceito(media);
        }
    }

    static void ExibirConceito(double media)
    {
        char conceito;

        if (media < 40)
        {
            conceito = 'F';
        }
        else if (media < 60)
        {
            conceito = 'E';
        }
        else if (media < 70)
        {
            conceito = 'D';
        }
        else if (media < 80)
        {
            conceito = 'C';
        }
        else if (media < 90)
        {
            conceito = 'B';
        }
        else
        {
            conceito = 'A';
        }

        Console.WriteLine($"Conceito: {conceito}");
    }
}
