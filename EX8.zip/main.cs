using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Digite um valor inteiro e positivo para N: ");
        int n = int.Parse(Console.ReadLine());

        double resultado = CalcularS(n);
        Console.WriteLine($"O valor de S é: {resultado}");
    }

    static double CalcularS(int n)
    {
        double soma = 0;

        for (int i = 1; i <= n; i++)
        {
            soma += (Math.Pow(i, 2) + 1) / (double)(i + 3);
        }

        return soma;
    }
}
