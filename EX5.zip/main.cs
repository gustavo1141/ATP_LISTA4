using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite dois números para calcular o MDC:");
        int num1 = int.Parse(Console.ReadLine());
        int num2 = int.Parse(Console.ReadLine());

        int mdc = CalcularMDC(num1, num2);
        Console.WriteLine($"O MDC de {num1} e {num2} é: {mdc}");
    }

    static int CalcularMDC(int a, int b)
    {
        // Algoritmo de Euclides para encontrar o MDC
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return Math.Abs(a); // Retorna o valor absoluto do MDC
    }
}
