using System;

class Program
{
    static void VerificarTriangulo(double x, double y, double z)
    {
        // Verifica se os lados podem formar um triângulo
        if (x + y > z && x + z > y && y + z > x)
        {
            // Verifica o tipo de triângulo
            if (x == y && y == z)
            {
                Console.WriteLine("Triângulo Equilátero");
            }
            else if (x == y || x == z || y == z)
            {
                Console.WriteLine("Triângulo Isósceles");
            }
            else
            {
                Console.WriteLine("Triângulo Escaleno");
            }
        }
        else
        {
            Console.WriteLine("Não é um triângulo válido");
        }
    }

    static void Main(string[] args)
    {
        char opcao;
        do
        {
            Console.WriteLine("Digite os comprimentos dos lados do triângulo:");
            double x = Convert.ToDouble(Console.ReadLine());
            double y = Convert.ToDouble(Console.ReadLine());
            double z = Convert.ToDouble(Console.ReadLine());

            VerificarTriangulo(x, y, z);

            Console.WriteLine("Deseja verificar outro triângulo? (s/n)");
            opcao = Console.ReadLine()[0];
        } while (opcao == 's' || opcao == 'S');
    }
}
