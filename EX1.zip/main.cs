using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Quantos alunos deseja calcular a média?");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nAluno {i + 1}:");
            Console.WriteLine("Digite as 3 notas do aluno (separadas por espaço):");
            string[] notasStr = Console.ReadLine().Split(' ');
            double[] notas = Array.ConvertAll(notasStr, Double.Parse);

            Console.WriteLine("Digite 'A' para calcular a média aritmética ou 'P' para calcular a média ponderada:");
            char opcao = Char.ToUpper(Console.ReadLine()[0]);

            if (opcao == 'A')
            {
                CalcularMediaAritmetica(notas);
            }
            else if (opcao == 'P')
            {
                CalcularMediaPonderada(notas);
            }
            else
            {
                Console.WriteLine("Opção inválida!");
            }
        }
    }

    static void CalcularMediaAritmetica(double[] notas)
    {
        double soma = 0;
        foreach (double nota in notas)
        {
            soma += nota;
        }
        double media = soma / notas.Length;
        Console.WriteLine($"A média aritmética é: {media}");
    }

    static void CalcularMediaPonderada(double[] notas)
    {
        double media = (notas[0] * 5 + notas[1] * 3 + notas[2] * 2) / 10;
        Console.WriteLine($"A média ponderada é: {media}");
    }
}
